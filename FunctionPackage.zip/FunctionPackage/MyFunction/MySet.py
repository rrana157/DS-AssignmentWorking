import logging


class MySet:
    def __init__(self, a):
        self.a = a
        logging.basicConfig(filename='LogFile/SetLog.log',
                            filemode='w',
                            level=logging.DEBUG,
                            format='%(asctime)s %(levelname)s %(message)s')

    def SetAdd(self, b):
        """
        This Function will add the given input to the set.
        Note:- if the given input already exists in set then it will not add.
        """
        try:
            if type(self.a) == set:
                temp_set = self.a
                temp_set.add(b)
                logging.info('Executed Successfully.')
                return temp_set
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def SetClear(self):
        """
        This Function will clear the given set.
        And it doesn't take any parameters.
        """
        try:
            if type(self.a) == set:
                tmp_set = self.a
                tmp_set.clear()
                logging.info('Executed Successfully.')
                return tmp_set
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def SetCopy(self):
        """
        This Function will copy the given set.
        And it doesn't take any parameters.
        """
        try:
            if type(self.a) == set:
                tmp_set = self.a
                tmp = tmp_set.copy
                logging.info('Executed Successfully.')
                return tmp
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def SetDifference(self, b):
        """
        This Function will return the difference between the given two inputs.
        """
        if type(self.a) == set and type(b) == set:
            try:
                tmp_set = self.a - b
                logging.info('Executed Successfully.')
                return tmp_set
            except Exception as e:
                logging.error("Error has happened")
                logging.exception('Exception occurred ' + str(e))
        else:
            raise Exception("Given Input is not a set.")

    def Set_difference_update(self, b):
        """
        This Function will Update the difference between the given two inputs.
        """
        if type(self.a) == set and type(b) == set:
            try:
                tmp_set = self.a
                tmp_set.difference_update(b)
                logging.info('Executed Successfully.')
                return tmp_set
            except Exception as e:
                logging.error("Error has happened")
                logging.exception('Exception occurred ' + str(e))
        else:
            raise Exception("Given input is not a set.")

    def Set_discard(self, b):
        """
        The Function will remove the element from the set only if the element is present in the set.
         If the element is not present in the set, then no error or exception is raised and the original set is printed.
        """
        try:
            if type(self.a) == set and type(b) == set:
                tmp_set = self.a
                tmp_set.discard(b)
                logging.info('Executed Successfully.')
                return tmp_set
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Set_intersection(self, b):
        """
        This Function will return the new set with an elements that is common to all set.
        """
        try:
            if type(self.a) == set and type(b) == set:
                tmp_set = self.a
                logging.info('Executed Successfully.')
                return (tmp_set & b)
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Set_intersection_update(self, *args):
        """
        This Function will update the Intersection of the given two inputs.
        """
        try:
            if type(self.a) == set:
                self.a.intersection_update(*args)
                logging.info('Executed Successfully.')
                return self.a
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Set_is_disjoint(self, b):
        """
        This Function will check whether the two sets are disjoint or not,
         if it is disjoint then it returns True otherwise it will return False.
        """
        try:
            if type(self.a) == set and type(b) == set:
                tmp_set = self.a
                logging.info('Executed Successfully.')
                return tmp_set.isdisjoint(b)
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Set_is_subset(self, b):
        """
        This Function will return all the true elements of set A are present in another set B.
        """
        try:
            if type(self.a) == set and type(b) == set:
                tmp_set = self.a
                logging.info('Executed Successfully.')
                return tmp_set.issubset(b)
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Set_is_superset(self, b):
        """
        This Function will return the SuperSet of the given two inputs.
        """
        try:
            if type(self.a) == set and type(b) == set:
                tmp_set = self.a
                logging.info('Executed Successfully.')
                return tmp_set.issuperset(b)
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def SetPOP(self):
        """
        This Function will remove the TOP element from the set but not the random element.
        """
        try:
            if type(self.a) == set:
                tmp_set = self.a
                tmp_set.pop()
                logging.info('Executed Successfully.')
                return tmp_set
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def SetRemove(self, b):
        """
        This function will remove the element from the set only if the element is present in the set,
        but If the element is not present in the set, then an error or exception is raised.
        """
        if type(self.a) == set:
            try:
                tmp_set = self.a
                tmp_set.remove(b)
                logging.info('Executed Successfully.')
                return tmp_set
            except Exception as e:
                logging.error("Error has happened")
                logging.exception('Exception occurred ' + str(e))
        else:
            raise Exception("Given input is not a set.")

    def SetUnion(self, *args):
        """
        This Function will return a new set which contains all the items from the original set.
        """
        try:
            if type(self.a) == set:
                tmp_set = self.a
                logging.info('Executed Successfully.')
                return tmp_set.union(*args)
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def SetUpdate(self, *args):
        """
        This Function will update the given inputs.
        """
        try:
            if type(self.a) == set:
                tmp_set = self.a
                tmp_set.update(*args)
                logging.info('Executed Successfully.')
                return tmp_set
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))



