import logging


class MyDict:
    def __init__(self, a):
        self.a = a
        logging.basicConfig(filename='LogFile/DictLog.log',
                            filemode='w',
                            level=logging.DEBUG,
                            format='%(asctime)s %(levelname)s %(message)s')

    def DictClear(self):
        """
        This Function will clear the Dictionary.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a
                ls_dict.clear()
                logging.info('Executed Successfully.')
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictCopy(self):
        """
        This Function will copy the Dictionary of the given inputs.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a
                ls_dict1 = ls_dict.copy()
                logging.info('Executed Successfully.')
                return ls_dict1
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictGet(self, b):
        """
        This Function will return the value for the given key if present in the dictionary.
        if not, then it will return None.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a
                logging.info('Executed Successfully.')
                return ls_dict.get(b)
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictItems(self):
        """
        This Function will return the Items from the Dictionary.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a.items()
                logging.info('Executed Successfully.')
                return ls_dict
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictKeys(self):
        """
        This Function will return the Keys from the Dictionary.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a.keys()
                logging.info('Executed Successfully.')
                return ls_dict
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictPOP(self, b):
        """
        This Function will delete from the end of the given Dictionary.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a
                ls_dict.pop(b)
                logging.info('Executed Successfully.')
                return ls_dict
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictPOPItem(self):
        """
        This Function will remove the last inserted key-values pair from the dictionary.
        And returns it as a tuple.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a
                ls_dict.popitem()
                logging.info('Executed Successfully.')
                return ls_dict
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictUpdate(self, b):
        """
        This Function will update the Dictionary with the elements from another
        dictionary object or from an iterable of key/value pairs.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a
                ls_dict.update(b)
                logging.info('Executed Successfully.')
                return ls_dict
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def DictValues(self):
        """
        This Function will return the value from the Dictionary.
        """
        try:
            if type(self.a) == dict:
                ls_dict = self.a.values()
                logging.info('Executed Successfully.')
                return ls_dict
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

