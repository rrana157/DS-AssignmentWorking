import logging


class MyTuple:
    def __init__(self, a):
        self.a = a
        logging.basicConfig(filename='LogFile/TupleLog.log',
                            filemode='w',
                            format='%(asctime)s %(levelname)s %(message)s',
                            level = logging.DEBUG)

    def TupleCount(self):
        """
        This Function will count the items in tuple.
        """
        try:
            if type(self.a) == tuple:
                cnt = 0
                for i in self.a:
                    cnt += 1
                logging.info("Executed Successfully.")
                return cnt
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def TupleIndex(self):
        """
        This Function will return the index of the items in tuple.
        """
        try:
            if type(self.a) == tuple:
                ind = []
                for i in range(len(self.a)):
                    ind.append(i)
                logging.info('Executed Successfully.')
                return tuple(ind)
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))


