import logging


class MyList:
    def __init__(self, a):
        self.a = a

        logging.basicConfig(filename='LogFile/ListLog.log',
                            filemode='w',
                            level=logging.DEBUG,
                            format='%(asctime)s %(levelname)s %(message)s')


    def ListAppend(self, b):
        """
        This Function will append/add the item to the end of list.
        """
        try:
            if type(self.a) == list:
                my_ls = list(self.a)
                my_ls.append(b)
                logging.info('Executed Successfully.')
                return my_ls
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def ListClear(self):
        """
        This Function will clear the list.
        """
        try:
            if type(self.a) == list:
                del self.a[:]
                logging.info('Executed Successfully.')
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Listcopy(self):
        """
        This Function will return the shallow copy of a list.
        And any modification in the new list won't be reflected in the original list.
        """
        try:
            if type(self.a) == list:
                lcopy = list(self.a)[:]
                logging.info('Executed Successfully.')
                return lcopy
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Listcount(self):
        """
        This Function will count the list items.
        """
        try:
            if type(self.a) == list:
                cnt = 0
                for i in self.a:
                    cnt += 1
                logging.info('Executed Successfully.')
                return cnt
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def Listextend(self):
        """
        This Function will copy the list into the new list.
        This appends all the elements of the iterable object.
        """
        try:
            if type(self.a) == list:
                l1_cpy = []
                l1_cpy.extend(list(self.a))
                logging.info('Executed Successfully.')
                return l1_cpy
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def ListIndex(self):
        """
        This Function will return the index of the list item.
        """
        try:
            if type(self.a) == list:
                ind = []
                for i in range(len(self.a)):
                    ind.append(i)
                logging.info('Executed Successfully.')
                return ind
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def ListInsert(self, b, c):
        """
        This Function will insert the new item in the given list.
        it required the index position where element/item needs to be inserted and
        the element which needs to be inserted.
        """
        try:
            if type(self.a) == list:
                out = list(self.a)
                out.insert(int(b),c)
                logging.info('Executed Successfully.')
                return out
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def ListPOP(self, b):
        """
        This Function will remove the last item from the given list.
        we can give the index which we want to remove. if the index
        is not given then it removed from last.
        """
        try:
            if type(self.a) == list:
                ls_pop = list(self.a)
                ls_pop.pop(int(b))
                logging.info('Executed Successfully.')
                return ls_pop
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def ListRemove(self, b):
        """
        This Function will remove the given object from the list.
        And does not return any value.
        """
        if type(self.a) == list:
            try:
                if b in list(self.a):
                    ls = list(self.a)
                    ls.remove(b)
                    logging.info('Executed Successfully.')
                    return ls
            except Exception as e:
                logging.error("Error has happened")
                logging.exception('Exception occurred ' + str(e))
        else:
            raise Exception("Given input is not a list.")

    def ListReverse(self):
        """
        This Function will return the list item in reverse order.
        """
        try:
            if type(self.a) == list:
                logging.info('Executed Successfully.')
                return self.a[::-1]
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))

    def ListSort(self):
        """
        This Function will return the list item in sorted order.
        """
        try:
            if type(self.a) == list:
                out = []
                for i in self.a:
                    out.append(i)
                    out.sort()
                logging.info('Executed Successfully.')
                return out
        except Exception as e:
            logging.error("Error has happened")
            logging.exception('Exception occurred ' + str(e))





