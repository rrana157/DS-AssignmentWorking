from MyFunction.MyTuple import MyTuple
from MyFunction.MyList import MyList
from MyFunction.MyDictionary import MyDict
from MyFunction.MySet import MySet

"""
Tuple
"""
tup = (1,2,3,4)
out = MyTuple(tup)
out1 = out.TupleCount()
print(out1)

"""
List
"""
ls1 = [1,2,3,4]
outl1 = MyList(ls1)
outl2 = outl1.ListIndex()
print(outl2)

"""
Dictionary
"""
dic1 = {'a': [1,2,3,4],'b':"ravender",'c':(1,2,3,4)}
outd1 = MyDict(dic1)
outd2 = outd1.DictItems()
print(outd2)

"""
Set
"""
set1 = {'a','b','c','d'}
set2 = {'e','f','g','h'}
outs1 = MySet(set1)
outs2 = outs1.SetUnion(set2)
print(outs2)
